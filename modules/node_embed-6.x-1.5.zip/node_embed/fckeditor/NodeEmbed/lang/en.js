FCKLang.NodeEmbedooltip = 'Node Embed' ;
FCKLang.NodeEmbedTitle = 'Embed' ;